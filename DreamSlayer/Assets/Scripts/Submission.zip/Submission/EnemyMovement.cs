using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public Transform leftBoundary;
    public Transform rightBoundary;
    public float normalMoveSpeed = 2.0f;
    public float chaseMoveSpeed = 1.0f;
    public float jumpForce = 5.0f;
    public LayerMask groundLayer;
    public float chaseRange = 5.0f;
    
    public float delayDuration = 2.0f; // Delay duration exposed in the inspector

    private bool movingRight = true;
    private Rigidbody2D rb;
    private Transform player;
    private bool delayMovement = true; // Flag to delay movement upon spawn

    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); 
        player = GameObject.FindWithTag("Player").transform; 

        StartCoroutine(StartDelay());
    }

    void Update()
    {
        if (!delayMovement)
        {
            Vector3 position = transform.position;

            float distanceToPlayer = Vector3.Distance(transform.position, player.position);

            if (distanceToPlayer <= chaseRange)
            {
                if (transform.position.x < player.position.x)
                {
                    position.x += chaseMoveSpeed * Time.deltaTime;
                }
                else
                {
                    position.x -= chaseMoveSpeed * Time.deltaTime;
                }
            }
            else
            {
                if (movingRight)
                {
                    position.x += normalMoveSpeed * Time.deltaTime;
                    if (position.x >= rightBoundary.position.x)
                    {
                        movingRight = false;
                    }
                }
                else
                {
                    position.x -= normalMoveSpeed * Time.deltaTime;
                    if (position.x <= leftBoundary.position.x)
                    {
                        movingRight = true;
                    }
                }
            }

            transform.position = position;

            if (IsGrounded() && Input.GetKeyDown(KeyCode.Space))
            {
                rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            }
        }
    }

    bool IsGrounded()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 0.1f, groundLayer);
        return hit.collider != null;
    }

    IEnumerator StartDelay()
    {
        yield return new WaitForSeconds(delayDuration); 
        delayMovement = false; 
    }
}
