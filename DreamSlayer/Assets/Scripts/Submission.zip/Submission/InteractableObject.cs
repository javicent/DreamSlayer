using UnityEngine;
using UnityEngine.SceneManagement;

public class InteractableObject : MonoBehaviour
{
    public float interactionRange = 2.0f;
    public bool isPickupable = false;

    private bool isInRange = false;
    private EnemySpawnManager enemySpawnManager;
    
    private GameManager gameManager;
    private AudioManager audioManager;

    void Awake()
    {
        enemySpawnManager = FindObjectOfType<EnemySpawnManager>(); 
        gameManager = FindObjectOfType<GameManager>();
        audioManager = FindObjectOfType<AudioManager>();

    }

    private void Update()
    {
        if (isInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (isPickupable)
            {
                Pickup();
            }
            else
            {
                Interact(); 
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isInRange = false;
        }
    }

    private void Pickup()
    {
        gameObject.SetActive(false);
    }

    public void Interact()
    {
        GameManager gameManager = FindObjectOfType<GameManager>();
        if (gameManager.CurrentPhase == 0 || (gameManager != null && gameManager.CurrentPhase != 2 && gameManager.pickupCount > 5))
        {
            gameManager.pickupCount = 0;
            gameManager.CurrentPhase++;
        }
        if(gameManager.CurrentPhase == 2 && gameManager.pickupCount > 0)
        {
            gameManager.EndState = true;
            audioManager.thanos();
            SceneManager.LoadScene("GameOver");
        }
    }
}
