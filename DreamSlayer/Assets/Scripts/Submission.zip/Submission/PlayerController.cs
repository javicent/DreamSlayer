using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5.0f;
    public float jumpForce = 10.0f;
    private float targetXPosition;
    private bool isDragging = false;
    private bool canJump = true;
    private Rigidbody2D rb;

    public Button interactButton;
    private GameManager gameManager; 

    private Collider2D triggerCollider; 
    private InteractableObject currentInteractableObject; 

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        interactButton.onClick.AddListener(OnInteractButtonClick);

        gameManager = FindObjectOfType<GameManager>();

        triggerCollider = GetComponent<Collider2D>();
    }

    void Update()
    {
        if (isDragging)
        {
            Vector3 currentPosition = transform.position;
            currentPosition.x = Mathf.MoveTowards(currentPosition.x, targetXPosition, moveSpeed * Time.deltaTime);
            transform.position = currentPosition;
        }

        if (canJump && Input.GetButtonDown("Jump"))
        {
            Jump();
        }

        if (currentInteractableObject != null && Input.GetKeyDown(KeyCode.E))
        {
            currentInteractableObject.Interact();
        }
    }

    public void StartDrag()
    {
        isDragging = true;
    }

    public void EndDrag()
    {
        isDragging = false;
    }

    public void SetTargetXPosition(float xPosition)
    {
        targetXPosition = xPosition;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Interactable"))
        {
            InteractableObject interactable = other.GetComponent<InteractableObject>();
            if (interactable != null)
            {
                currentInteractableObject = interactable;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Interactable"))
        {
            currentInteractableObject = null;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            canJump = true;
        }
    }

    public void Jump()
    {
        if (canJump)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    public void OnInteractButtonClick()
    {
        if (currentInteractableObject != null)
        {
            currentInteractableObject.Interact();
        }
    }
}
