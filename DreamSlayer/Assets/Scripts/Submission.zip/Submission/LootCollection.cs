using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LootCollection : MonoBehaviour
{
    private Dictionary<string, int> lootCounts = new Dictionary<string, int>();

    public void IncrementLootCount(string enemyType)
    {
        if (lootCounts.ContainsKey(enemyType))
        {
            lootCounts[enemyType]++;
        }
        else
        {
            lootCounts[enemyType] = 1;
        }
    }

    public int GetLootCount(string enemyType)
    {
        if (lootCounts.ContainsKey(enemyType))
        {
            return lootCounts[enemyType];
        }
        return 0;
    }
}
